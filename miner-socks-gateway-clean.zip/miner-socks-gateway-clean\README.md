# Miner SOCKS Gateway

Node.js SOCKS5 矿池中转与监控，支持 PRL / QTC、多个监听端口、直连或上游 SOCKS5、TLS 卸载与重新加密、钱包白名单、NOCK 双挖、dev 份额归类，以及基于份额难度的算力估算。

后端业务代码全部在一个 `server.js` 中。前端使用 Tailwind CSS，支持深色 / 浅色模式与中英文切换，选择保存在浏览器本地；已提供编译好的 CSS，运行时无需 CDN 或前端构建服务。

## 安装和启动

需要 Node.js 22 或更新版本。

```sh
npm ci --omit=dev
npm start
```

打开 <http://127.0.0.1:3320/>。项目附带 `data/config.json` 默认配置（空矿池、空白名单、模式 2、无预设入口），首次启动直接使用，并在 `data/` 中补齐本地 CA 等运行文件。可以先编辑该文件预设矿池、钱包、白名单和 SOCKS5 入口，也可以在页面中配置；两者等价，页面保存会更新同一个文件。

`data/config.json` 中的 `settings.routing.knownWallets` 预置了内置已知 dev 钱包，`settings.nock.wallets` 默认为空（不替换 NOCK 地址，需要时填入目标钱包），`settings.web` 控制管理页面的监听地址与端口（默认 `127.0.0.1:3320`，`WEB_HOST` / `WEB_PORT` 环境变量优先）。文件会按当前版本补全缺失字段，手动编辑时保持 JSON 格式即可。

修改前端样式时安装完整依赖并重新编译：

```sh
npm ci
npm run build
```

后端可用 `npm run check` 检查语法。

## 目录

```text
server.js             后端、SOCKS5、TLS、协议处理、监控接口
public/index.html     页面
public/app.js         前端交互、中英文词条与主题切换
public/input.css      Tailwind 样式源文件
public/style.css      已编译样式
public/icon.svg       图标
certs/gateway-ca.pem          随项目分发的默认根证书
certs/gateway-ca-key.pem      默认根证书私钥
certs/gateway-server-key.pem  固定的叶证书私钥，保持网关公钥稳定
data/config.json      首次启动前的默认配置：空矿池、空白名单、模式 2，可直接编辑
package.json          项目与依赖配置
package-lock.json     锁定依赖版本
README.md             使用说明
.gitignore            运行文件排除规则
```

分发目录只包含以上文件。`data/` 中除 `config.json` 外的运行文件（CA、固定叶证书私钥、事件日志）与 `node_modules/` 在首次启动、安装依赖时生成。首次启动使用 `certs/` 中的默认根证书按原目标签发叶证书；也可上传自己的 CA 或服务端证书替换。

## 配置入口

1. 打开“配置矿池 / 钱包”，启用 PRL / QTC，设置预设矿池、TCP / TLS 和钱包白名单，并按需填写 NOCK 双挖白名单。
2. 创建一个或多个本地 SOCKS5 入口，每个入口都能承接两个币种。
3. 每个入口可独立选择直连，或通过上游 SOCKS5；入口和上游代理的认证均可选。
4. miner 的代理指向本地入口。本机使用 `127.0.0.1`；接收局域网矿机时可监听 `0.0.0.0`，矿机连接本程序所在电脑的局域网 IP。

所有入口共享矿池、钱包和证书配置。修改共享配置会断开当前连接，miner 重连后生效；修改入口只影响该入口。

入口支持 SOCKS5 TCP CONNECT，用于 PRL / QTC 按行 JSON 矿池协议；不支持 UDP ASSOCIATE 或 BIND。

## 钱包模式与白名单

每个币种独立配置白名单，每行一个钱包，也可用逗号分隔；最多 100 项。第一项用于替换，名单中的其他钱包保留地址。匹配时忽略 `.矿机名` 和 `+` 协议后缀。

| 模式 | 钱包情况 | 钱包处理 | 矿池处理 |
| --- | --- | --- | --- |
| 模式 1：仅处理已知 dev | 已知 dev，且不在白名单 | 替换为白名单第一项 | 使用预设矿池 |
| 模式 1 | 白名单内，或其他普通钱包 | 保留地址 | 保留 SOCKS5 原目标 |
| 模式 2：统一矿池 | 白名单内 | 保留地址 | 使用预设矿池 |
| 模式 2 | 白名单外 | 替换为白名单第一项 | 使用预设矿池 |

默认模式 2。模式 1 保留原目标时，仍通过该入口配置的直连或上游 SOCKS5 出站；原 TCP 保持 TCP，原 TLS 卸载后重新以 TLS 连接原目标。

### 内置 dev 钱包与 devfee

内置 PRL 地址：

```text
prl1p5ga7tw6vy5rjr59wewzq3u4sp064muwssdglatxdj3wrz0yzqamshydnnk
prl1pjutfahremf6qejpv4mvrrntnh0mxw0wtxhzr346g525gvyzy3n8s3zy4v8
```

内置 QTC 地址：

```text
qzoVPWdDhYt68NGtGf74eLJyoknS4hzreaeQT7zQEZwKb59vV
```

内置 NOCK 地址：

```text
2uU54pCLrkUfqxMNqyp9QBBk3U6AwTXHR8hXygfwtJSQhj5swmSKaTB
```

内置名单自动保留，可在页面补充其他 dev 钱包。两种钱包模式都会识别名单，并将这些来源的矿机名统一为 **`devfee`**，应用于登录、提交和监控分组。

例如名单外 dev 登录 `DEV_WALLET.6600+proof`，目标钱包为 `YOUR_WALLET`，发往矿池的登录为 `YOUR_WALLET.devfee+proof`。已知 dev 钱包在白名单中时，地址仍保留，矿机名改为 `devfee`。普通钱包保留原矿机名；替换时也保留 PRL 的 `+` 协议后缀。

支持 PRL 对象或数组形式的 `mining.authorize`、QTC 的 `login`，以及拆包、合包、CRLF 和重复授权。需要改写时保留 Job、nonce、证明、agent、type 等其他内容。配置矿池密码后，仅在使用预设矿池时应用该密码。

PRL 先订阅后授权时，模式 1 会先连接原矿池；授权命中 dev 名单后重放订阅并更新 extranonce。若新旧 extranonce 不同，矿机需要声明支持 `mining.extranonce.subscribe` 或 `subscribe-extranonce` 扩展。首包直接授权的 PRL v2 流程无需订阅切换。

### NOCK 双挖（PRL 端口 3360 / 3361 / 3362）

端口为 3360、3361、3362 的矿池支持 NOCK 双挖。miner 的 PRL 登录钱包带 `+` 后缀时视为开启双挖，发往矿池的钱包统一为 `PRL钱包+NOCK钱包.矿机名`（例如 `PRL_ADDRESS+NOCK_ADDRESS.worker`）：

- NOCK 白名单由所有入口共享，最多 100 项；第一项用于替换，填写时不含 `+` 与空白。**默认留空：只检测双挖并按下方规则处理 PRL，不替换 NOCK 地址**；需要替换时在“配置矿池 / 钱包”的 NOCK 双挖白名单中填写目标钱包。
- PRL 地址与 NOCK 地址分别判断：白名单内保留原地址，白名单外替换为对应名单第一项；两侧都不需要替换、且格式已符合 `PRL钱包+NOCK钱包.矿机名` 时保持原始字节。
- 矿机名位于 `+NOCK钱包` 之后；写在 `+` 之前或 NOCK 地址之后都会识别，缺失时不追加 `.矿机名`。
- 已知 dev 来源（含内置 NOCK dev 钱包）按替换目标整单改写，矿机名统一为 `devfee`。
- 模式 1 只处理已知 dev 来源，其他连接保持原钱包与原矿池；模式 2 下所有非白名单地址都会被替换。非 3360 / 3361 / 3362 端口的 `+` 内容仍按原协议后缀保留，不追加 NOCK 钱包。

## TLS

支持 TCP → TCP、TCP → TLS、TLS → TCP 和 TLS → TLS。入口可以自动识别明文登录与 TLS ClientHello。

默认生成并持久保存本地 CA，按原目标 / SNI 签发证书；也可上传自定义 CA 或固定服务端证书及配套私钥。固定证书应覆盖 miner 请求的域名。miner 开启证书验证时，需要信任页面下载的公开证书；不能绕过客户端的证书固定校验。

矿池 TLS 默认验证证书；私有矿池可上传 CA，或配置服务器名称。没有正常运行连接的空闲断开计时，支持 TCP 半关闭。

## 监控

“矿机份额”和“实时连接”分别显示：

- 目标 host / 端口、实际矿池、上下行网速和累计流量。
- 按币种、客户端 IP、矿机名、实际钱包汇总 Job 与提交 / 接受 / 拒绝。
- 离线状态、最后活动和距上次提交时间。
- 原钱包红字红叉、替换后钱包绿字打勾。
- 当前难度，以及近 1h / 6h 的估算算力。
- **挽回的损失**：devfee 行在份额旁显示这一标签，数量沿用原有的提交 / 接受 / 拒绝统计。
- 双挖连接单独显示原 / 实际 NOCK 钱包与替换结果。

页面右上角可切换深色 / 浅色模式与中英文界面，选择保存在浏览器本地。

每次提交时固定 Job 难度与矿机分组，难度变化、重新授权和延迟响应不会把份额归到新的矿机。相同 Job 内容在同一连接内去重计数。

### 算力口径

`估算算力 = 窗口内提交份额对应的工作量总和 ÷ 统计秒数`。

优先用矿池 Job 的 target 计算工作量。PRL 使用 256 位 target，QTC 使用 512 位 target；只有难度字段时，PRL 按 `difficulty × 2^32`，QTC 按 `difficulty` 换算。旧 Job 提交仍使用其原有难度。

计算包括拒绝份额，是提交算力估算。窗口未满 1h / 6h 时按实际观测时长计算并显示 `*`；无法识别难度的份额单独提示，不补造工作量。份额少时估算会波动。离线后窗口继续滚动。

## 保存与分发

配置（`data/config.json`，随包提供默认值，页面保存后更新）、代理密码、自定义私钥及生成的 CA 存放于运行时的 `data/`。诊断事件保存为 `data/events.jsonl`，达到大小限制后轮转；页面不显示活动记录区，原始 Job 和明文流不落盘。普通启动重置本次运行的统计，配置和证书保留。

更新时可从受保护的 `/api/runtime` 保存运行统计，并通过 `RUNTIME_SNAPSHOT` 指向该 JSON 文件恢复。历史 dev 行恢复为 `devfee` 时合并其计数及工作量。

上传 GitHub 使用这个干净源码目录。`.gitignore` 排除了运行数据、依赖、环境文件和日志，只保留随项目分发的默认根证书与私钥；源码包中不含使用者的矿池、钱包（除内置已知 dev 钱包）、上游地址、生产记录或认证配置。

## 环境变量

| 名称 | 默认值 | 用途 |
| --- | --- | --- |
| `WEB_HOST` | `127.0.0.1` | 管理页面监听地址；设置后优先于配置中的 `settings.web.host` |
| `WEB_PORT` | `3320` | 管理页面端口；设置后优先于配置中的 `settings.web.port` |
| `WEB_TOKEN` | 空 | HTTP Basic 管理密码，用户名为 `admin`；对外监听时必填 |
| `DATA_DIR` | 项目下的 `data` | 运行配置、证书和日志目录 |
| `RUNTIME_SNAPSHOT` | 空 | 更新时恢复运行统计的 JSON 文件 |

管理页面的监听地址与端口按 `WEB_HOST` / `WEB_PORT` 环境变量、`data/config.json` 的 `settings.web`、默认 `127.0.0.1:3320` 的顺序取值，修改后重启程序生效；端口不能与已启用的 SOCKS5 入口冲突，对外监听必须设置 `WEB_TOKEN`。远程管理可通过 HTTPS 反向代理访问。SOCKS5 的监听地址与上游代理地址是两个独立配置，监听地址必须属于运行本程序的电脑。
